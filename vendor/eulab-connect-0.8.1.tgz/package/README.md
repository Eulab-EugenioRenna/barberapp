# EULab Connect SDK

SDK ESM per SSO, permessi, utenti e WhatsApp tramite EULab Connect. Richiede un'installazione Connect configurata; il server SDK richiede Node.js 22 o successivo.

```sh
npm install @eulab/connect
```

```ts
import {ConnectBrowser} from '@eulab/connect/browser';

// Mantieni un'istanza condivisa nel service dell'applicazione.
const connect = new ConnectBrowser({
  apiUrl: 'https://auth.eulab.cloud',
  issuer: 'https://auth.eulab.cloud/sso/realms/eulab',
  clientId: 'client-id-della-tua-app',
  redirectUri: 'https://app.example/callback',
  installationId: 'id-installazione',
});
await connect.init({loginRequired: true});
```

L'entrypoint server espone `ConnectServer` e `verifyWebhook`:

```ts
import {ConnectServer, verifyWebhook} from '@eulab/connect/server';
```

Gli export browser e server includono le dichiarazioni TypeScript. Il pacchetto contiene solo JavaScript compilato, tipi e questo README; non contiene credenziali o profili WhatsApp. I segreti dell’installazione devono rimanere sul backend. Il backend deve verificare licenza e permessi per ogni operazione.

`ConnectServer.mirrorUser()` collega un utente locale a Connect. Il campo opzionale `initialPassword` proviene da una verifica locale appena conclusa, serve solo a inizializzare una nuova identità nel provider e non viene conservato da Connect. Non è disponibile nell’SDK browser.

Le API `/v1/team` sono esposte da `teamOverview`, `teamUsers`, `teamRoles`, `teamFunctions`, `createTeamRole`, `updateTeamRole`, `deleteTeamRole`, `setTeamUserRoles`, `revokeTeamUser` e `restoreTeamUser`. Cliente e applicazione derivano dall’installazione autenticata; ogni assegnazione resta limitata a funzioni attive, licenziate e presenti nella delega del chiamante. Le operazioni di modifica richiedono `team.manage` nella delega effettiva.
